//
//  ReceiptDetailsVC.swift
//  WABOOKS_iOS_V2
//
//  Created by Mok Monita on 11/1/21.
//

import UIKit

class ReceiptDetailsVC: UIViewController {
    
    //MARK: - @IBOutlet 
    @IBOutlet weak var labelReceiptTitle    : UILabel!
    @IBOutlet weak var buttonDeleteReceipt  : UIButton!
    @IBOutlet weak var buttonEditReceipt    : UIButton!
    @IBOutlet weak var tableView            : UITableView!
    @IBOutlet weak var cstHideEditBtn       : NSLayoutConstraint!
    @IBOutlet weak var viewlineBtwEditAndDeleteBtn: UIView!
    
    
    //MARK: - Variable
    var receiptList     : WABOOKS_MREC_R006.RESPONSE.REC?
    var numberOfRows    : ReceiptDetailsRow.receiptRow?
    var receiptDetailVM = ReceiptDetailsVM()
    var settingVM       = SettingVM()
     
    var receiptImage    : UIImageView?
    
    
    //MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
  
        //cannot edit if CEO purpose
        if let _ = receiptList?.ADV_PAYM_TRNS_SEQ {
//            buttonEditReceipt.isHidden  = true
//            cstHideEditBtn.constant     = -38 //-38 hide , 5 not hide
//            viewlineBtwEditAndDeleteBtn.isHidden = true
//            buttonEditReceipt.isEnabled                 = false
//            buttonDeleteReceipt.isEnabled               = false
//            viewlineBtwEditAndDeleteBtn.backgroundColor = UIColor(hexString: "#FFFFFF").withAlphaComponent(0.2)
        }
        
        self.fetchingSetting()
        self.setupTable()
        self.setLocalized()
        
    }
     
    // Set status bar style into light content (white color)
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    // Segue
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        switch segue.identifier {
        case NotifyKey.gotoPhotoPreviewVC.rawValue :
            let vc = segue.destination as! PhotoPreviewVC
            vc.currentIndexImage = 0
            vc.imageUrlArray    = [["RCPT_IMG_URL" : getValue(from: .ATTACHMEMNT)]] as Array<AnyObject>
            vc.cc_setZoomTransition(originalView: receiptImage!) // Zoom trasition for receipt image
        default: break
             
        }
    }
    
    //MARK: - @IBAction
    @IBAction func didTapDismissAction(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func didTapDeleteReceiptButtonAction(_ sender: UIButton) {
        
        buttonAnimation(btn: sender) {
            self.customAlert(type       : .YES_OR_NO_ALERT,
                             image      : "badge_warning",
                             title      : "delete_receipt".localized,
                             message    : "\("would_you_like_to_delete_the_receipt".localized)\n\("you_will_not_be_able_to_restore_the_delete_receipts".localized)",
                             redTitle   : "delete".localized,
                             greyTitle  : "cancel".localized) { (isOk) in
                
                if isOk {
                    if self.receiptList?.PC_MOD_YN == "Y" { //  PC_MOD_YN == "Y" Can't delete or Edit this kind of receipt
                        self.customAlert(type       : .CONFIRM_ALERT,
                                         image      : "badge_failed",
                                         title      : "notification".localized,
                                         message    : "you_cannot_delete_a_receipt".localized,
                                         redTitle   : "",
                                         greyTitle  : "ok".localized) { _ in
                        }
                    }
                    else {
                        self.updateOrDeleteReceipt(CORR_TYPE: "D") // D: Delete Receipt
                    }
                }
            }
        }
    }
    
    @IBAction func didTapEditReceiptButtonAction(_ sender: UIButton) {
        buttonAnimation(btn: sender) {
            if self.receiptList?.PC_MOD_YN == "Y" {
                self.customAlert(type       : .CONFIRM_ALERT,
                                 image      : "badge_failed",
                                 title      : "notice".localized,
                                 message    : "you_cannot_edit_a_receipt".localized,
                                 redTitle   : "",
                                 greyTitle  : "ok".localized) { _ in
                }
            }
            else {
                let vc = self.VC(sbName: "SubmitReceiptSB", identifier: "SubmitReceiptVC") as! SubmitReceiptVC
                vc.receiptList = self.receiptList
                self.presetVC(vc: vc)
            }
        }
    }
    
    //MARK: - Private func
    private func setupRow() {
        var username: String = ""
        if let USER_NM = self.receiptList?.USER_NM {
            username = USER_NM
        }
        else {
            username = Shared.R002_DATA?.USER_NM ?? ""
        }
          
        let currency = "\(self.receiptList?.TRCO_TRSC_CCY_CD ?? "") \( formatCurrency(type: self.receiptList?.TRCO_TRSC_CCY_CD ?? "", amount: self.receiptList?.TOTL_AMT ?? ""))"
         
        numberOfRows = ReceiptDetailsRow.receiptRow(content: [
            ReceiptDetailsRow.receiptRow.contents(code: "TTL", value: currency),
            ReceiptDetailsRow.receiptRow.contents(code: "PURP", value: (self.receiptList?.USAG_NM ?? "")),
            ReceiptDetailsRow.receiptRow.contents(code: "USER", value: username) ,
            ReceiptDetailsRow.receiptRow.contents(code: "DESCR", value: self.receiptList?.CONT),
            ReceiptDetailsRow.receiptRow.contents(code: "ATTC", value: self.receiptList?.SAVE_FILE_NM)
        ])
        
        
        /// Rabbit
        // TRCO_TYPE
        self.supplier(type: TypeOfSupplier(rawValue: self.receiptList?.TRCO_TYPE ?? "1") ?? .TaxablePerson)
        /**
         Check display cell based on Input Item from Settings
         - "Y" : Open ( false ),
         - "N" : Close ( true )
         */
        if !(self.settingVM.settingsResponse?.INPUT_FIELD_SET_YN ?? false) {
            numberOfRows?.content.removeAll(where: { $0.code != "TTL" && $0.code != "ATTC" && $0.code != "RCTNO" && $0.code != "DESCR" })
        }
        else {
            if !(self.settingVM.settingsResponse?.TRSC_AMT_YN ?? false) {
                removeIndexOf(key: .AMOUNT)
            }
            if !(self.settingVM.settingsResponse?.TRCO_YN ?? false) {
                removeIndexOf(key: .DESCRIPTION)
            }
            if !(self.settingVM.settingsResponse?.TRSC_DT_YN ?? false) {
                removeIndexOf(key: .DATE)
            }
            if !(self.settingVM.settingsResponse?.USAG_CD_YN ?? false) {
                removeIndexOf(key: .PURPOSE)
            }
            if !(self.settingVM.settingsResponse?.USER_NM_YN ?? false) {
                removeIndexOf(key: .USER)
            }
        }
         
        let purp2 = ReceiptDetailsRow.receiptRow.contents(code: "ADVL", value: self.receiptList?.ADV_PAYM_NM)
        let debit_date = ReceiptDetailsRow.receiptRow.contents(code: "DEBDATE", value: self.receiptList?.TRSC_DT)
        if let _ = self.receiptList?.ADV_PAYM_TRNS_SEQ, let _ = self.receiptList?.ADV_PAYM_NM {
            (self.settingVM.settingsResponse?.USAG_CD_YN ?? false) ? numberOfRows?.content.insert(purp2, at: 1) : ()
            
            // What if in receipt detail dispay date of Advance Ledger, display here
            (self.settingVM.settingsResponse?.USAG_CD_YN ?? false) ? numberOfRows?.content.insert( debit_date, at: 3) : ()
            self.tableView.reloadData()
        }
        else {
            return
        }
        
    }
     
    private func removeIndexOf(key: ReceiptRow) {
        numberOfRows?.content.removeAll(where: { $0.code == key.rawValue})
    }
    
    // retrieve value base on code
    private func getValue(from code: ReceiptRow) -> String {
        var val: String = ""
        for (_, value) in (numberOfRows?.content ?? []).enumerated() {
            if value.code == code.rawValue {
                val = (value.value ?? "")
            }
        }
        
        return val
    }
     
    private func alertMessage(title: String = "", msg: String, _ completion: @escaping () -> () = {}) {
        self.customAlert(type       : .CONFIRM_ALERT,
                         image      : "badge_failed",
                         title      : title,
                         message    : msg,
                         redTitle   : "",
                         greyTitle  : "ok".localized) { (_) in
            completion()
        }
    }
    
    private func setupTable() {
        self.tableView.tableFooterView  = UIView()
    }
    
    private func setLocalized() {
        self.labelReceiptTitle.text = "receipt_details".localized
        self.labelReceiptTitle.getlocalizedFont()
        
    }
    
    // get idx for insert email, tel, address if Type of Supplier is Non-Taxable Person or Oversea Company
    private func validatedWithSettingIndex() -> Int {
        var index : Int = -1
        if let content = numberOfRows?.content {
            for (idx, value) in content.enumerated() {
                if value.code == "USER" {
                    index = idx
                }
                else if value.code == "DESCR" && !(content.contains(where: { $0.code == "USER" })) {
                    index = idx
                }
            }
        }
        
        return index
    }
     
    /// Rabbit
    private func supplier(type: TypeOfSupplier) {
        switch type {
        case .TaxablePerson:
            print("TaxablePerson")
        case .NonTaxablePerson:
            if let content = numberOfRows?.content {
                if !(content.contains(where: { $0.code == "TEL" })) {
                    let tel = ReceiptDetailsRow.receiptRow.contents(code: "TEL", value: receiptList?.TRCO_RPRS_TLPH)
                    let row = self.validatedWithSettingIndex()
                    numberOfRows?.content.insert(tel, at: row)
                }
            }
             
        case .OverseaCompany:
            if let content = numberOfRows?.content {
                if !(content.contains(where: { $0.code == "TEL" })) {
                    let tel = ReceiptDetailsRow.receiptRow.contents(code: "TEL", value: receiptList?.TRCO_RPRS_TLPH)
                    let row = self.validatedWithSettingIndex()
                    numberOfRows?.content.insert(tel, at: row)
                }
                if !(content.contains(where: { $0.code == "EMAIL" })) {
                    let email = ReceiptDetailsRow.receiptRow.contents(code: "EMAIL", value: receiptList?.EML)
                    let row = self.validatedWithSettingIndex()
                    numberOfRows?.content.insert(email, at: row)
                }
                if !(content.contains(where: { $0.code == "ADDR" })) {
                    let add = [receiptList?.TRCO_BSUN_POST_ADRS ?? "", receiptList?.TRCO_BSUN_DTL_ADRS ?? "", receiptList?.TRCO_BSUN_CITY ?? "", receiptList?.TRCO_BSUN_ST ?? ""]
                    let new_address = add.filter({ !($0.isEmpty) }).joined(separator: ", ")
                     
                    let address = ReceiptDetailsRow.receiptRow.contents(code: "ADDR", value: new_address)
                    let row = self.validatedWithSettingIndex()
                    numberOfRows?.content.insert(address, at: row)
                }
            }
        }
    }
    
    // Fetching API
    private func updateOrDeleteReceipt(CORR_TYPE: String) {
        if self.receiptList?.TOTL_AMT == "0" {  // if The total amount equal "0" => The total amount is empty
            self.receiptList?.TOTL_AMT = ""
        }
        
        self.receiptDetailVM.updateOrDelete(body                : WABOOKS_MREC_C004.REQUEST(CORR_TYPE: "", DOC_ID: "", TRCO_CMNM: "", USE_DT: "", TRCO_TRSC_CCY_CD: "", TOTL_AMT: "", BUSA_USAG_CD: "", CONT: "", USER_NM: "", REG_DT: "", SEQ_NO: "", FILE_URL: "", ADV_PAYM_TRNS_SEQ: "", ADV_PAYM_SEQ: "", HAND_DOC_ID: "", TRCO_TYPE: "", TRCO_TAX_ID: "", APLY_EXCH_RATE: "", TRCO_RPRS_TLPH: "", GST_NO: "", EML: "", TRCO_BSUN_POST_ADRS: "", TRCO_BSUN_DTL_ADRS: "", TRCO_BSUN_ST: "", TRCO_BSUN_CITY: "", REC1: [WABOOKS_MREC_C004.REQUEST.REC1(FILE_ID: "")], REC2: [WABOOKS_MREC_C004.REQUEST.REC2(FILE_NM: "", FILE_DATA: "")])) { (result) in
            
//            CORR_TYPE           : CORR_TYPE,
//            DOC_ID              : (self.receiptList?.DOC_ID ?? ""),
//            TRCO_CMNM           : (self.receiptList?.TRCO_CMNM ?? ""),
//            USE_DT              : (self.receiptList?.USE_DT ?? ""),
//            TRCO_TRSC_CCY_CD    : (self.receiptList?.TRCO_TRSC_CCY_CD ?? ""),
//            TOTL_AMT            : (self.receiptList?.TOTL_AMT ?? ""),
//            BUSA_USAG_CD        : (self.receiptList?.BUSA_USAG_CD ?? ""),
//            CONT                : (self.receiptList?.CONT ?? ""),
//            USER_NM             : (self.receiptList?.USAG_NM ?? ""),
//            REG_DT              : (self.receiptList?.REG_DT ?? ""),
//            SEQ_NO              : (self.receiptList?.SEQ_NO ?? ""),
//            FILE_URL            : self.receiptList?.SAVE_FILE_NM ?? "",
//            ADV_PAYM_TRNS_SEQ   : (self.receiptList?.ADV_PAYM_TRNS_SEQ ?? ""),
//            ADV_PAYM_SEQ        : "",
//            HAND_DOC_ID         : self.receiptList?.HAND_DOC_ID ?? ""
            
            switch result {
            case .success(_):
                self.dismiss(animated: true) {
                    MyNotify.send(name: .reloadAfterUpdateOrDeleteOrSubmit, object: ["CORR_TYPE": "D"] as AnyObject)
                }
            case .failure(let error):
                self.alertMessage(title: "notice".localized, msg: error.localizedDescription)
            }
        }
    }
    
    private func fetchingSetting() {
        self.settingVM.fetchInputSettings { (result) in
            switch result {
            case .success(_):
                DispatchQueue.main.async {
                    self.setupRow()
                    self.tableView.reloadData()
                } 
            case .failure(let error):
                self.alertMessage(title: "notice".localized, msg: error.localizedDescription)
            }
        }
    }
    
    //MARK: - @objc func
    @objc func previewImage() { 
        self.performSegue(withIdentifier: NotifyKey.gotoPhotoPreviewVC.rawValue, sender: nil)
    }
     
}

//MARK: - UITableView
extension ReceiptDetailsVC: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (numberOfRows?.content.count ?? 0)
    }
     
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat { 
        return UITableView.automaticDimension
    }
     
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let rows        = numberOfRows?.content[indexPath.row]
        let mappingRow  = ReceiptRow(rawValue: rows?.code ?? "")
        
        if mappingRow == .HEADER {
            let cell = tableView.dequeueReusableCell(withIdentifier: "HeaderReceiptDetailsCell", for: indexPath) as! HeaderReceiptDetailsCell
            cell.configCell(title       : rows?.value ?? "",
                            date        : self.receiptList?.USE_DT ?? "",
                            week        : self.receiptList?.TRSC_WEEK ?? "",
                            receipt_no  : self.receiptList?.HAND_DOC_ID ?? "",
                            merchant    : self.receiptList?.CONT ?? "",
                            taxable     : "",
                            tax_id      : "")
            return cell
        }
        else if mappingRow == .ATTACHMEMNT {
            let cell = tableView.dequeueReusableCell(withIdentifier: "AttachmentDetailsCell", for: indexPath) as! AttachmentDetailsCell
            
            // Preview image
            cell.imageViewImg.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(previewImage)))
            
            // assign Image View for zoom animation 
            receiptImage = cell.imageViewImg
            
            cell.configCell(img: receiptList?.REC1?.first?.FILE_URL ?? "")
//            cell.setupImageForReceipt(imageURL: receiptList?.REC1?.first?.FILE_URL ?? "")
//            cell.setupImageForReceipt(imageURL: rows?.value ?? "")

            return cell
        }
        else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "ReceiptDetailCell", for: indexPath) as! ReceiptDetailCell
            cell.setUpCell(row: (rows ?? ReceiptDetailsRow.receiptRow.contents(code: "")))
            return cell
        }
    }
}
