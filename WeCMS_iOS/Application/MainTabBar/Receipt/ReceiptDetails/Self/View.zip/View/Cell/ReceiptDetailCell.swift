//
//  ReceiptDetailCell.swift
//  WABOOKS_iOS_V2
//
//  Created by Mok Monita on 11/1/21.
//

import UIKit
import SDWebImage
import SkeletonView

class ReceiptDetailCell: UITableViewCell {
    
    //MARK: - @IBOutlet
    @IBOutlet weak var labelTitle   : UILabel!
    @IBOutlet weak var imageViewIcon: UIImageView!
    @IBOutlet weak var labelValue   : UILabel!
    
    
    //MARK: - Lifecycle
    override func awakeFromNib() {
        super.awakeFromNib()
       
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func setUpCell(row: ReceiptDetailsRow.receiptRow.contents) {
        
        let mappingRow = ReceiptRow(rawValue: row.code)
         
        self.labelValue.getlocalizedFont()
        self.labelTitle.getlocalizedFont()
        
        switch mappingRow {
  
        case .PURPOSE:
            self.labelTitle.text        = mappingRow?.description.localized
            self.imageViewIcon.image    = UIImage(named: "list_purpose_ico")
            self.labelValue.text        = row.value
            
        case .TEL:
            self.labelTitle.text        = mappingRow?.description.localized
            self.imageViewIcon.image    = UIImage(named: "list_phone_number_ico")
            self.labelValue.text        = row.value
            
        case .EMAIL:
            
            self.labelTitle.text        = mappingRow?.description.localized
            self.imageViewIcon.image    = UIImage(named: "list_email.ico")
            self.labelValue.text        = row.value
            
        case .ADDRESS: 
            self.labelTitle.text        = mappingRow?.description.localized
            self.imageViewIcon.image    = UIImage(named: "list_addr_ico")
            self.labelValue.text        = row.value
        
        case .MERCHANT:
            self.labelTitle.text        = mappingRow?.description.localized
            self.imageViewIcon.image    = UIImage(named: "list_merchant_ico")
            self.labelValue.text        = row.value
            
        case .DATE:
            self.labelTitle.text        = mappingRow?.description.localized
            self.imageViewIcon.image    = UIImage(named: "list_debit_date_ico")
            self.labelValue.text        = formatteDate(date: row.value ?? "")
             
        case .ADVANCELEDGER:
            self.labelTitle.text        = mappingRow?.description.localized
            self.imageViewIcon.image    = UIImage(named: "list_advance_ledger_ico")
            self.labelValue.text        = row.value
            
        case .DEBITDATE:
            self.labelTitle.text        = mappingRow?.description.localized
            self.imageViewIcon.image    = UIImage(named: "list_debit_date_ico")
            self.labelValue.text        = formatteDate(date: row.value ?? "")
          
        case .USER:
            self.labelTitle.text        = mappingRow?.description.localized
            self.imageViewIcon.image    = UIImage(named: "list_user_ico")
            self.labelValue.text        = row.value
            
        case .DESCRIPTION:
            self.labelTitle.text        = mappingRow?.description.localized
            self.imageViewIcon.image    = UIImage(named: "list_descrip_ico")
            self.labelValue.text        = row.value
            
        default: break
        }
    }

}


class HeaderReceiptDetailsCell: UITableViewCell {
    
    //MARK: - @IBOutlet
    @IBOutlet weak var labelTitle           : UILabel!
    @IBOutlet weak var labelDate            : UILabel!
    @IBOutlet weak var lblReceiptNo         : UILabel!
    @IBOutlet weak var lblMerchant          : UILabel!
    @IBOutlet weak var lblTaxablePersonTaxID: UILabel!
    
    
    //MARK: - Lifecycle
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    //MARK: - Customize func
    func configCell(title: String, date: String, week: String = "", receipt_no: String = "", merchant: String = "", taxable: String = "", tax_id: String = "") {
         
        self.labelDate.text             =  formatteDate(date: date, week: week.localized) //formatteDate(date: date) //customDate(date: date)
        self.labelTitle.text            = title
        self.lblReceiptNo.text          = receipt_no
        self.lblMerchant.text           = merchant
        
        if taxable.isEmpty && tax_id.isEmpty {
            self.lblTaxablePersonTaxID.text = ""
        }
        else {
            self.lblTaxablePersonTaxID.text = "\(taxable) \(tax_id)"
        }
         
        self.labelTitle.getlocalizedFont()
        self.labelDate.getlocalizedFont()
        self.lblReceiptNo.getlocalizedFont()
        self.lblMerchant.getlocalizedFont()
        self.lblTaxablePersonTaxID.getlocalizedFont()
    }

}

	
class AttachmentDetailsCell: UITableViewCell {
    
    //MARK: - @IBOutlet
    @IBOutlet weak var labelAttachment  : UILabel!
    @IBOutlet weak var imageViewImg     : UIImageView!
    @IBOutlet weak var skeletonView     : UIView!
    
    let imgCache    = NSCache<NSString, UIImage>()
    
    //MARK: - Lifecycle
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.setLocalized()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func configCell(img url: String = "") {
        DispatchQueue.main.async {
            // set app_name as key for each cache
            let keyForCache = NSString(string: url)

            // share to cache when every reuse data as array cache
            if self.imgCache.object(forKey: keyForCache) == nil {
                self.setupImageForReceipt(imageURL: url, keyForCache: keyForCache)
            }
            else {
                self.imageViewImg.image = self.imgCache.object(forKey: keyForCache)
            }
        }
    }
    
    func getCurrentDate() -> String {
        let date = Date()
        let df  = DateFormatter()
        df.dateFormat = "yyyyMMddHHmmss"
        let dateString = df.string(from: date)
        return dateString
    }
    
    func saveCache(key: NSString, image: UIImage) {
        imgCache.setObject(image, forKey: "\(key)\(getCurrentDate())" as NSString)
    }
 
    //MARK: - Customize func
    func setupImageForReceipt(imageURL: String, keyForCache: NSString) {
        //setup skeleton
        
        skeletonView.isHidden           = false
        skeletonView.backgroundColor    = .white
        skeletonView.isSkeletonable     = true
        skeletonView.showAnimatedGradientSkeleton()
        
        let authorization   = "\(Shared.R002_DATA?.ACCESS_TOKEN ?? "")"
        let split_url       = imageURL.components(separatedBy: "?")
        let img_url         = "\(split_url.first ?? "")?token=\(authorization)&\(split_url.last ?? "")"
        let url             = URL(string: img_url)
        
        self.imageViewImg.sd_setImage(with: url, completed: { (image, error, SDImageCacheType, url) in
            self.skeletonView.isHidden       = true
            if error == nil { // Success
                let size        = image?.size
                var widthPic    : CGFloat = 0
                var heightPic   : CGFloat = 0
                
                widthPic        = (size?.width)!
                heightPic       = (size?.width)!
                 
                // The shortest side
                let sideLength      = min(widthPic, heightPic)
                
                // Determines the x,y coordinate of a centered
                // sideLength by sideLength square
                let xOffset         = ((size?.width)! - sideLength) / 2.0
                let yOffset         = ((size?.height)! - sideLength) / 2.0
                let cropImg         : CGRect    = CGRect(x: xOffset, y: yOffset, width: widthPic, height: heightPic)
                
                let cgImage         : CGImage   = image!.cgImage!.cropping(to: cropImg)!
                let croppedImage    : UIImage   = UIImage(cgImage: cgImage)
                
                /// ImageView
                self.imageViewImg.contentMode     = .scaleAspectFill
                self.imageViewImg.clipsToBounds   = true
                self.imageViewImg.image           = croppedImage
                
                self.saveCache(key: NSString(string: keyForCache), image: croppedImage)
            }
            else {
                self.imageViewImg.image         = UIImage()
                self.imageViewImg.contentMode   = .scaleAspectFill
                
                self.saveCache(key: NSString(string: keyForCache), image: UIImage(named: "noimage")!)
            }
        })
    }
    
    private func setLocalized() {
        self.labelAttachment.text = ReceiptRow.ATTACHMEMNT.description.localized
        self.labelAttachment.getlocalizedFont()
    }

}
